# Bible Scripture files

This archive contains the four ShareAlike editions in the Bible app, as book JSON files.
You may copy, share, and adapt these files under the
[Creative Commons Attribution-ShareAlike 4.0 International license](https://creativecommons.org/licenses/by-sa/4.0/).

## Literal Standard Version (`lsv/`)

Literal Standard Version (LSV). Copyright © 2020 Covenant Press and the Covenant Christian Coalition. Licensed under [Creative Commons Attribution-ShareAlike 4.0 International](https://creativecommons.org/licenses/by-sa/4.0/). Source: [Covenant Press via Open.Bible](https://open.bible/bibles/english-covenant-text-bible/). Converted from USX to the app format.

- [Publisher and permissions](https://www.lsvbible.com/get-the-lsv)
- [Publisher source archive](https://openbible-api-1.biblica.com/artifactContent/64bff5e9fc80f074487a4e79)

## Free Bible Version (`fbv/`)

Free Bible Version (FBV), version 5.2, by Dr. Jonathan Gallagher. Copyright Free Bible Ministry, Inc. Licensed under the [Creative Commons Attribution-ShareAlike 4.0 International license](https://creativecommons.org/licenses/by-sa/4.0/). Source: [Free Bible Version](https://www.freebibleversion.org/). Converted from USX to the app format. Footnotes are included.

- [Publisher and downloads](https://www.freebibleversion.org/)
- [Version 5.2 source archive](https://openbible-api-1.biblica.com/artifactContent/68de89c141a2a80e0f03b709)

## Literal Text (`ult/`)

Literal Text, v92 (34 Old Testament books and the New Testament). Copyright © 2022 by unfoldingWord. The original work by unfoldingWord is available from [unfoldingword.org/ult](https://www.unfoldingword.org/ult). Developed by the Door43 World Missions Community. Licensed under [Creative Commons Attribution-ShareAlike 4.0 International](https://creativecommons.org/licenses/by-sa/4.0/). Converted from USFM to the app format. Footnotes are included. Alignment markup and branding are omitted.

- [Source and license](https://git.door43.org/unfoldingWord/en_ult/src/tag/v92/LICENSE.md)
- [Publisher licensing information](https://unfoldingword.org/about/license/)

## Simplified Text (`ust/`)

Simplified Text, v92 (34 Old Testament books and the New Testament). Copyright © 2022 by unfoldingWord. The original work by unfoldingWord is available from [unfoldingword.org/ust](https://www.unfoldingword.org/ust). Developed by the Door43 World Missions Community. Licensed under [Creative Commons Attribution-ShareAlike 4.0 International](https://creativecommons.org/licenses/by-sa/4.0/). Based on [A Translation For Translators](https://git.door43.org/Door43/T4T) by Ellis W. Deibler, Jr., also licensed under CC BY-SA 4.0. Converted from USFM to the app format. Footnotes are included. Alignment markup and branding are omitted.

- [Source and license](https://git.door43.org/unfoldingWord/en_ust/src/tag/v92/LICENSE.md)
- [Publisher licensing information](https://unfoldingword.org/about/license/)
